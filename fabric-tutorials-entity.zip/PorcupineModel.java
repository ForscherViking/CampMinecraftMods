// Made with Blockbench 4.8.3
// Exported for Minecraft version 1.17+ for Yarn
// Paste this class into your mod and generate all required imports
public class porcupine-vanilla extends EntityModel<Entity> {
	private final ModelPart porcupine;
	private final ModelPart body;
	private final ModelPart torso;
	private final ModelPart tail;
	private final ModelPart cube_r1;
	private final ModelPart cube_r2;
	private final ModelPart head;
	private final ModelPart skull;
	private final ModelPart hair;
	private final ModelPart cube_r3;
	private final ModelPart cube_r4;
	private final ModelPart left_eyelid;
	private final ModelPart right_eyelid;
	private final ModelPart spikes;
	private final ModelPart spike;
	private final ModelPart spike2;
	private final ModelPart spike5;
	private final ModelPart spike3;
	private final ModelPart spike4;
	private final ModelPart spikes2;
	private final ModelPart spike6;
	private final ModelPart spike7;
	private final ModelPart spike8;
	private final ModelPart spike9;
	private final ModelPart spike10;
	private final ModelPart spikes3;
	private final ModelPart spike11;
	private final ModelPart spike12;
	private final ModelPart spike13;
	private final ModelPart spike14;
	private final ModelPart spike15;
	private final ModelPart spikes4;
	private final ModelPart spike16;
	private final ModelPart spike17;
	private final ModelPart spike18;
	private final ModelPart spike19;
	private final ModelPart spike20;
	private final ModelPart spikes5;
	private final ModelPart spike21;
	private final ModelPart spike22;
	private final ModelPart spike23;
	private final ModelPart spike24;
	private final ModelPart spike25;
	private final ModelPart spikes6;
	private final ModelPart spike26;
	private final ModelPart spike27;
	private final ModelPart spike28;
	private final ModelPart spike29;
	private final ModelPart spike30;
	private final ModelPart spikes7;
	private final ModelPart spike31;
	private final ModelPart spike32;
	private final ModelPart spike33;
	private final ModelPart spike34;
	private final ModelPart spike35;
	private final ModelPart spikes8;
	private final ModelPart spike36;
	private final ModelPart spike37;
	private final ModelPart spike38;
	private final ModelPart spike39;
	private final ModelPart spike40;
	private final ModelPart left_front_leg;
	private final ModelPart right_front_leg;
	private final ModelPart right_back_leg;
	private final ModelPart left_back_leg;
	public porcupine-vanilla(ModelPart root) {
		this.porcupine = root.getChild("porcupine");
	}
	public static TexturedModelData getTexturedModelData() {
		ModelData modelData = new ModelData();
		ModelPartData modelPartData = modelData.getRoot();
		ModelPartData porcupine = modelPartData.addChild("porcupine", ModelPartBuilder.create(), ModelTransform.pivot(0.0F, 24.0F, 0.0F));

		ModelPartData body = porcupine.addChild("body", ModelPartBuilder.create(), ModelTransform.pivot(0.0F, -4.0F, 0.0F));

		ModelPartData torso = body.addChild("torso", ModelPartBuilder.create().uv(0, 0).cuboid(-3.0F, -3.0F, -4.0F, 6.0F, 5.0F, 8.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, 0.0F, 0.0F));

		ModelPartData tail = torso.addChild("tail", ModelPartBuilder.create(), ModelTransform.of(0.5F, -1.251F, 4.0F, -0.4363F, 0.0F, 0.0F));

		ModelPartData cube_r1 = tail.addChild("cube_r1", ModelPartBuilder.create().uv(11, 25).cuboid(-6.0F, -0.499F, -1.0F, 7.0F, 0.0F, 7.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 0.25F, 0.0F, 0.0F, 0.9599F, 0.0F));

		ModelPartData cube_r2 = tail.addChild("cube_r2", ModelPartBuilder.create().uv(11, 25).cuboid(-6.0F, 0.001F, -1.0F, 7.0F, 0.0F, 7.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 0.25F, 0.0F, 0.0F, 0.6109F, 0.0F));

		ModelPartData head = torso.addChild("head", ModelPartBuilder.create(), ModelTransform.of(0.0F, -1.0F, -4.0F, 0.0F, -0.0436F, 0.0F));

		ModelPartData skull = head.addChild("skull", ModelPartBuilder.create().uv(0, 13).cuboid(-2.0F, -2.0F, -4.0F, 4.0F, 4.0F, 4.0F, new Dilation(0.0F))
		.uv(0, 14).cuboid(1.1F, -0.75F, -3.25F, 1.0F, 1.0F, 1.0F, new Dilation(0.0F))
		.uv(12, 13).cuboid(1.425F, -0.975F, -3.025F, 1.0F, 1.0F, 1.0F, new Dilation(-0.3F))
		.uv(0, 14).mirrored().cuboid(-2.1F, -0.75F, -3.25F, 1.0F, 1.0F, 1.0F, new Dilation(0.0F)).mirrored(false)
		.uv(12, 13).mirrored().cuboid(-2.425F, -0.975F, -3.025F, 1.0F, 1.0F, 1.0F, new Dilation(-0.3F)).mirrored(false)
		.uv(16, 18).cuboid(-1.0F, -0.25F, -5.0F, 2.0F, 2.0F, 1.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, 0.0F, 0.0F));

		ModelPartData hair = skull.addChild("hair", ModelPartBuilder.create().uv(0, 16).cuboid(0.0F, -4.0F, 0.0F, 0.0F, 5.0F, 5.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, -1.0F, -4.0F, 0.5236F, 0.0F, 0.0F));

		ModelPartData cube_r3 = hair.addChild("cube_r3", ModelPartBuilder.create().uv(0, 16).cuboid(0.0F, -4.0F, 0.0F, 0.0F, 5.0F, 5.0F, new Dilation(0.0F)), ModelTransform.of(-0.5F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2618F));

		ModelPartData cube_r4 = hair.addChild("cube_r4", ModelPartBuilder.create().uv(0, 16).cuboid(0.0F, -4.0F, 0.0F, 0.0F, 5.0F, 5.0F, new Dilation(0.0F)), ModelTransform.of(0.5F, 0.0F, 0.0F, 0.0F, 0.0F, 0.2618F));

		ModelPartData left_eyelid = skull.addChild("left_eyelid", ModelPartBuilder.create().uv(24, 0).cuboid(0.1F, -1.75F, -7.25F, 2.0F, 2.0F, 2.0F, new Dilation(-0.4F)), ModelTransform.pivot(-0.4F, 0.5F, 3.5F));

		ModelPartData right_eyelid = skull.addChild("right_eyelid", ModelPartBuilder.create().uv(24, 0).mirrored().cuboid(-2.1F, -1.75F, -7.25F, 2.0F, 2.0F, 2.0F, new Dilation(-0.4F)).mirrored(false), ModelTransform.pivot(0.4F, 0.5F, 3.5F));

		ModelPartData spikes = torso.addChild("spikes", ModelPartBuilder.create(), ModelTransform.pivot(0.0F, -3.0F, -3.5F));

		ModelPartData spike = spikes.addChild("spike", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -7.0F, 0.0F, 0.0F, 7.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 0.0F, 0.5F, 0.0F, 0.0F, -0.0436F));

		ModelPartData spike2 = spikes.addChild("spike2", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -7.0F, 0.0F, 0.0F, 7.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0873F));

		ModelPartData spike5 = spikes.addChild("spike5", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -7.0F, 0.0F, 0.0F, 7.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(2.0F, 0.0F, 0.5F, 0.0F, 0.0F, 0.3491F));

		ModelPartData spike3 = spikes.addChild("spike3", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -7.0F, 0.0F, 0.0F, 7.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(-1.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.1309F));

		ModelPartData spike4 = spikes.addChild("spike4", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -7.0F, 0.0F, 0.0F, 7.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(-2.0F, 0.0F, 0.5F, 0.0F, 0.0F, -0.4363F));

		ModelPartData spikes2 = torso.addChild("spikes2", ModelPartBuilder.create(), ModelTransform.of(0.5F, -3.0F, -2.5F, 0.3054F, 0.0F, 0.0F));

		ModelPartData spike6 = spikes2.addChild("spike6", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -7.0F, 0.0F, 0.0F, 7.0F, 1.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, 0.0F, -1.0F));

		ModelPartData spike7 = spikes2.addChild("spike7", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -7.0F, 0.0F, 0.0F, 7.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(1.0F, 0.0F, -1.5F, 0.0F, 0.0F, 0.2618F));

		ModelPartData spike8 = spikes2.addChild("spike8", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -7.0F, 0.0F, 0.0F, 7.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(2.0F, 0.0F, -1.0F, 0.0F, 0.0F, 0.4363F));

		ModelPartData spike9 = spikes2.addChild("spike9", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -7.0F, 0.0F, 0.0F, 7.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(-1.0F, 0.0F, -1.5F, 0.0F, 0.0F, -0.3054F));

		ModelPartData spike10 = spikes2.addChild("spike10", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -7.0F, 0.0F, 0.0F, 7.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(-2.0F, 0.0F, -1.0F, 0.0F, 0.0F, -0.6545F));

		ModelPartData spikes3 = torso.addChild("spikes3", ModelPartBuilder.create(), ModelTransform.of(0.5F, -3.0F, -2.5F, -0.1745F, 0.0F, 0.0F));

		ModelPartData spike11 = spikes3.addChild("spike11", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -7.0F, 0.0F, 0.0F, 7.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 0.0F, 0.5F, 0.0F, 0.0F, 0.1309F));

		ModelPartData spike12 = spikes3.addChild("spike12", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -7.0F, 0.0F, 0.0F, 7.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.1309F));

		ModelPartData spike13 = spikes3.addChild("spike13", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -7.0F, 0.0F, 0.0F, 7.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(2.0F, 0.0F, 0.5F, 0.0F, 0.0F, 0.2618F));

		ModelPartData spike14 = spikes3.addChild("spike14", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -7.0F, 0.0F, 0.0F, 7.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(-1.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.0436F));

		ModelPartData spike15 = spikes3.addChild("spike15", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -7.0F, 0.0F, 0.0F, 7.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(-2.0F, 0.0F, 0.5F, 0.0F, 0.0F, -0.1745F));

		ModelPartData spikes4 = torso.addChild("spikes4", ModelPartBuilder.create(), ModelTransform.of(0.0F, -3.0F, -2.0F, -0.5672F, 0.0F, 0.0F));

		ModelPartData spike16 = spikes4.addChild("spike16", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -6.0F, 0.0F, 0.0F, 6.0F, 1.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, 0.0F, 0.5F));

		ModelPartData spike17 = spikes4.addChild("spike17", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -6.0F, 0.0F, 0.0F, 6.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.1745F));

		ModelPartData spike18 = spikes4.addChild("spike18", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -6.0F, 0.0F, 0.0F, 6.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(2.0F, 0.0F, 0.5F, 0.0F, 0.0F, 0.2182F));

		ModelPartData spike19 = spikes4.addChild("spike19", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -6.0F, 0.0F, 0.0F, 6.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(-1.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.0873F));

		ModelPartData spike20 = spikes4.addChild("spike20", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -6.0F, 0.0F, 0.0F, 6.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(-2.0F, 0.0F, 0.5F, 0.0F, 0.0F, -0.1309F));

		ModelPartData spikes5 = torso.addChild("spikes5", ModelPartBuilder.create(), ModelTransform.of(0.0F, -3.0F, 0.0F, -0.7854F, 0.0F, 0.0F));

		ModelPartData spike21 = spikes5.addChild("spike21", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -6.0F, 0.0F, 0.0F, 6.0F, 1.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, 0.0F, 0.5F));

		ModelPartData spike22 = spikes5.addChild("spike22", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -6.0F, 0.0F, 0.0F, 6.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.4363F));

		ModelPartData spike23 = spikes5.addChild("spike23", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -6.0F, 0.0F, 0.0F, 6.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(2.0F, 0.0F, 0.5F, 0.0F, 0.0F, 0.7854F));

		ModelPartData spike24 = spikes5.addChild("spike24", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -6.0F, 0.0F, 0.0F, 6.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(-1.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2618F));

		ModelPartData spike25 = spikes5.addChild("spike25", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -6.0F, 0.0F, 0.0F, 6.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(-2.0F, 0.0F, 0.5F, 0.0F, 0.0F, -0.5672F));

		ModelPartData spikes6 = torso.addChild("spikes6", ModelPartBuilder.create(), ModelTransform.of(0.5F, -3.0F, -0.5F, -0.6545F, 0.0F, 0.0F));

		ModelPartData spike26 = spikes6.addChild("spike26", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -5.0F, 0.0F, 0.0F, 5.0F, 1.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, 0.0F, 0.5F));

		ModelPartData spike27 = spikes6.addChild("spike27", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -5.0F, 0.0F, 0.0F, 5.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.3491F));

		ModelPartData spike28 = spikes6.addChild("spike28", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -5.0F, 0.0F, 0.0F, 5.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(2.0F, 0.0F, 0.5F, 0.0F, 0.0F, 0.48F));

		ModelPartData spike29 = spikes6.addChild("spike29", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -5.0F, 0.0F, 0.0F, 5.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(-1.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2182F));

		ModelPartData spike30 = spikes6.addChild("spike30", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -5.0F, 0.0F, 0.0F, 5.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(-2.0F, 0.0F, 0.5F, 0.0F, 0.0F, -0.48F));

		ModelPartData spikes7 = torso.addChild("spikes7", ModelPartBuilder.create(), ModelTransform.of(0.5F, -3.0F, 1.5F, -0.9599F, 0.0F, 0.0F));

		ModelPartData spike31 = spikes7.addChild("spike31", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -4.0F, 0.0F, 0.0F, 4.0F, 1.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, 0.0F, 0.5F));

		ModelPartData spike32 = spikes7.addChild("spike32", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -4.0F, 0.0F, 0.0F, 4.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.1309F));

		ModelPartData spike33 = spikes7.addChild("spike33", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -4.0F, 0.0F, 0.0F, 4.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(2.0F, 0.0F, 0.5F, 0.0F, 0.0F, 0.3491F));

		ModelPartData spike34 = spikes7.addChild("spike34", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -4.0F, 0.0F, 0.0F, 4.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(-1.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.1309F));

		ModelPartData spike35 = spikes7.addChild("spike35", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -4.0F, 0.0F, 0.0F, 4.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(-2.0F, 0.0F, 0.5F, 0.0F, 0.0F, -0.3054F));

		ModelPartData spikes8 = torso.addChild("spikes8", ModelPartBuilder.create(), ModelTransform.of(0.0F, -3.0F, 3.0F, -1.0472F, 0.0F, 0.0F));

		ModelPartData spike36 = spikes8.addChild("spike36", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -3.0F, 0.0F, 0.0F, 3.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 0.0F, 0.5F, 0.0F, 0.0F, -0.1309F));

		ModelPartData spike37 = spikes8.addChild("spike37", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -3.0F, 0.0F, 0.0F, 3.0F, 1.0F, new Dilation(0.0F)), ModelTransform.pivot(1.0F, 0.0F, 0.0F));

		ModelPartData spike38 = spikes8.addChild("spike38", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -3.0F, 0.0F, 0.0F, 3.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(2.0F, 0.0F, 0.5F, 0.0F, 0.0F, 0.3927F));

		ModelPartData spike39 = spikes8.addChild("spike39", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -3.0F, 0.0F, 0.0F, 3.0F, 1.0F, new Dilation(0.0F)), ModelTransform.pivot(-1.0F, 0.0F, 0.0F));

		ModelPartData spike40 = spikes8.addChild("spike40", ModelPartBuilder.create().uv(20, 0).cuboid(0.0F, -3.0F, 0.0F, 0.0F, 3.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(-2.0F, 0.0F, 0.5F, 0.0F, 0.0F, -0.3054F));

		ModelPartData left_front_leg = body.addChild("left_front_leg", ModelPartBuilder.create().uv(0, 0).cuboid(-1.0F, -1.0F, -1.0F, 2.0F, 5.0F, 2.0F, new Dilation(0.0F)), ModelTransform.pivot(3.0F, 0.0F, -2.5F));

		ModelPartData right_front_leg = body.addChild("right_front_leg", ModelPartBuilder.create().uv(0, 0).mirrored().cuboid(-1.0F, -1.0F, -1.0F, 2.0F, 5.0F, 2.0F, new Dilation(0.0F)).mirrored(false), ModelTransform.pivot(-3.0F, 0.0F, -2.5F));

		ModelPartData right_back_leg = body.addChild("right_back_leg", ModelPartBuilder.create().uv(0, 0).mirrored().cuboid(-1.0F, -1.0F, -1.0F, 2.0F, 5.0F, 2.0F, new Dilation(0.0F)).mirrored(false), ModelTransform.pivot(-3.0F, 0.0F, 2.5F));

		ModelPartData left_back_leg = body.addChild("left_back_leg", ModelPartBuilder.create().uv(0, 0).cuboid(-1.0F, -1.0F, -1.0F, 2.0F, 5.0F, 2.0F, new Dilation(0.0F)), ModelTransform.pivot(3.0F, 0.0F, 2.5F));
		return TexturedModelData.of(modelData, 32, 32);
	}
	@Override
	public void setAngles(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
	}
	@Override
	public void render(MatrixStack matrices, VertexConsumer vertexConsumer, int light, int overlay, float red, float green, float blue, float alpha) {
		porcupine.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
	}
}